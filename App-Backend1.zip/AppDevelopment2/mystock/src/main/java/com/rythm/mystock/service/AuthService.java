package com.rythm.mystock.service;

import com.rythm.mystock.dto.request.LoginRequest;
import com.rythm.mystock.dto.request.RegisterRequest;
import com.rythm.mystock.dto.response.LoginResponse;

public interface AuthService {
    String register(RegisterRequest registerRequest);

    LoginResponse login(LoginRequest loginRequest);

    String createAdmin();
}

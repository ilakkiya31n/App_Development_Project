package com.rythm.mystock.service;

import java.util.List;

import com.rythm.mystock.dto.request.SiteRequest;
import com.rythm.mystock.dto.response.SiteResponse;

public interface WebService {

    List<SiteResponse> getSiteData();

    String addSiteData(SiteRequest siteRequest);

    SiteResponse updateSiteData(SiteRequest siteRequest, Long id);

}

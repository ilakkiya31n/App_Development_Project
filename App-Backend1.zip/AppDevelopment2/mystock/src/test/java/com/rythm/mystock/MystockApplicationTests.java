package com.rythm.mystock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MystockApplicationTests {

	@Test
	void contextLoads() {
	}

}

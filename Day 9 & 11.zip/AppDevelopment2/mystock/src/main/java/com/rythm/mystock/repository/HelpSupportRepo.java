package com.rythm.mystock.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rythm.mystock.model.HelpSupport;

public interface HelpSupportRepo  extends  JpaRepository<HelpSupport,String>{

}

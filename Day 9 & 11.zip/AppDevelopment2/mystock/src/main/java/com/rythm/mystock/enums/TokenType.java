package com.rythm.mystock.enums;

public enum TokenType {
    BEARER
}